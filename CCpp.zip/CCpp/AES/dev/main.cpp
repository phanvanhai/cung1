#include <iostream>
#include "../src/AES.h"
using namespace std;

int main()
{
  cout << "Aes dev" << endl;
  return 0;
}
