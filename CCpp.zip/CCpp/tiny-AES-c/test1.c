#include <stdio.h>
#include <string.h>
#include <stdint.h>
typedef uint8_t BYTE;

// Enable ECB, CTR and CBC mode. Note this can be done before including aes.h or at compile-time.
// E.g. with GCC by using the -D flag: gcc -c aes.c -DCBC=0 -DCTR=1 -DECB=1
#define ECB 1

#include "aes.h"

void string2ByteArray(char *input, BYTE *output)
{
    int loop;
    int i;

    loop = 0;
    i = 0;

    while (input[loop] != '\0')
    {
        output[i++] = input[loop++];
    }
}

static int test_decrypt_ecb(char *str_in, char *str_key)
{
    int len = strlen(str_in);
    BYTE arr_in[len];
    //converting string to BYTE[]
    string2ByteArray(str_in, arr_in);

    len = strlen(str_key);
    BYTE arr_key[len];
    //converting string to BYTE[]
    string2ByteArray(str_key, arr_key);

    printf("ECB decrypt:\n");
    for (int i = 0; i < (strlen(str_in) / 16); i++)
    {
        struct AES_ctx ctx;
        AES_init_ctx(&ctx, arr_key);
        AES_ECB_decrypt(&ctx, arr_in + 16 * i);

        for (int ii = 0; ii < 16; ++ii)
        {
            printf("%c", arr_in[16 * i + ii]);
        }
    }
}

int main(void)
{

    int exit;
    char in[] = "33olcEhFRM80EqyKkmpr2NIqAFHTxMR+E9QgmpgeRxz/mXVE5QScCi75AeQSDolPtl/F3rzr4/UutonjiLiGZnpAWkhjVmvpOtsuxHgiPLXZ/QzWr/SJeuE+Kt57AzfA/51yVk4OrJNTEhE6Xot63V/sAdvuE5WIQjUcb5wmWRG4W42l7/AWjoz6F0Y8H2AcCrsRA/lWFhXs+6Q2AUt8hJXprIEB+sFp4hW+wRrMeoIkF7ch+uZUvs5Zec6kJZHC";
    char key[] = "03564c78aaab6d75";
    exit = test_decrypt_ecb(in, key);

    return exit;
}
