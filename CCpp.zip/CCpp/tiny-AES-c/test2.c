#include <stdio.h>
#include <openssl/aes.h>
#include <string.h>
#include <stdlib.h>
#include <openssl/rand.h>

//static const unsigned char key[]={01234567890123456789012345678900};

int main()
{

    int keylength;
    printf("Give a key length [only 128 or 192 or 256]:\n");
    scanf("%d", &keylength);

    /* generate a key with a given length */
    unsigned char aes_key[keylength];
    memset(aes_key, 0, sizeof(aes_key));
    if (!RAND_bytes(aes_key, keylength))
    {
        exit(-1);
    }
    aes_key[keylength - 1] = '\0';

    unsigned char text[] = "TestText.  TestText."; //Assign text to be encrypted
    unsigned char enc_out[AES_BLOCK_SIZE];         //Set to 16 bytes
    unsigned char dec_out[AES_BLOCK_SIZE];

    AES_KEY enc_key, dec_key; //establish AES enc and dec key

    AES_set_encrypt_key(aes_key, 128, &enc_key);
    AES_encrypt(text, enc_out, &enc_key);

    AES_set_decrypt_key(aes_key, 128, &dec_key);
    AES_decrypt(enc_out, dec_out, &dec_key);

    int x;

    printf("original:\t");
    for (x = 0; *(text + x) != 0x00; x++)
        printf("%X ", *(text + x));
    printf("\nencrypted:\t");
    for (x = 0; *(enc_out + x) != 0x00; x++)
        printf("%X ", *(enc_out + x));
    printf("\ndecrypted:\t");
    for (x = 0; *(dec_out + x) != 0x00; x++)
        printf("%X ", *(dec_out + x));
    printf("\n");

    return 0;
}
